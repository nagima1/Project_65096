import streamlit as st
import pandas as pd
import joblib
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import re

# Load Model 
@st.cache_resource
def load_model():
    model = joblib.load(r"C:\Users\NZHOLDOS\Desktop\65096_Project_final\sentiment_model.pkl")
    vectorizer = joblib.load(r"C:\Users\NZHOLDOS\Desktop\65096_Project_final\vectorizer.pkl")
    return model, vectorizer

model, tfidf_vectorizer = load_model()

# Clean Text 
def preprocess(text):
    text = str(text).lower()
    text = re.sub(r'\d+', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    return text

# Sentiment Mapping 
def map_sentiment(pred):
    mapping = {
        0: ("🔴 Negative", "⭐"),
        1: ("🟡 Neutral", "⭐⭐⭐"),
        2: ("🟢 Positive", "⭐⭐⭐⭐⭐", "⭐⭐⭐⭐")
    }
    return mapping.get(pred, ("Unknown", ""))


st.title("🛍️ Review Analyzer: Understand Customer Opinions")
st.markdown("This dashboard uses machine learning to classify product review sentiments and visualize the results.")

#  User Review Input 
st.header("📝 Try It Yourself: Write a Review")
user_review = st.text_area("Write a product review:")

# Save session logs
if "logs" not in st.session_state:
    st.session_state.logs = []

if st.button("Predict Sentiment for Text"):
    if user_review.strip():
        cleaned = preprocess(user_review)
        review_vector = tfidf_vectorizer.transform([cleaned])
        prediction = model.predict(review_vector)[0]
        sentiment_label, stars = map_sentiment(prediction)

        st.success(f"### Sentiment: {sentiment_label}")
        st.markdown(f"#### Star Rating: {stars}")

        # Log the prediction
        st.session_state.logs.append({
            "Review": user_review,
            "Sentiment": sentiment_label,
            "Stars": stars
        })
    else:
        st.warning("⚠️ Please enter your review.")

# CSV Upload Section 
st.header("📂 Upload CSV File for Bulk Sentiment Analysis")
uploaded_file = st.file_uploader("Upload a CSV file containing a 'Review' column", type=['csv'])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    if 'Review' not in df.columns:
        st.error("❌ CSV file must contain a 'Review' column.")
    else:
        st.write("✅ File successfully uploaded.")
        
        df['Cleaned'] = df['Review'].apply(preprocess)
        vectors = tfidf_vectorizer.transform(df['Cleaned'])
        predictions = model.predict(vectors)
        
        df['Sentiment'], df['Stars'] = zip(*[map_sentiment(pred) for pred in predictions])
        st.dataframe(df[['Review', 'Sentiment', 'Stars']])

        # Option to download
        csv_out = df[['Review', 'Sentiment', 'Stars']].to_csv(index=False).encode('utf-8')
        st.download_button("📥 Download Results as CSV", data=csv_out, file_name="sentiment_results.csv", mime="text/csv")

        # Pie chart for uploaded data
        st.subheader("📊 Sentiment Distribution (Uploaded File)")
        sentiment_counts = df['Sentiment'].value_counts()
        fig, ax = plt.subplots()
        ax.pie(sentiment_counts, labels=sentiment_counts.index, autopct='%1.1f%%', colors=sns.color_palette('Set2'))
        ax.axis('equal')
        st.pyplot(fig)

# Display User Session Logs 
if st.session_state.logs:
    st.header("🧾 Your Prediction History")
    log_df = pd.DataFrame(st.session_state.logs)
    st.dataframe(log_df, use_container_width=True)

# Word Cloud 
st.header("🌈 Common Sentiment Words")
sample_data = pd.DataFrame({
    'Sentiment': np.random.choice(['Negative', 'Neutral', 'Positive'], 100),
})
wordcloud_text = ' '.join(sample_data['Sentiment'])
wordcloud = WordCloud(width=800, height=400, background_color='black', colormap='plasma').generate(wordcloud_text)
fig_wc, ax_wc = plt.subplots()
ax_wc.imshow(wordcloud, interpolation='bilinear')
ax_wc.axis('off')
st.pyplot(fig_wc)

# instructions 
st.markdown("---")
st.caption("📘 Built by Nagima :)")
if st.sidebar.button("Help & Instructions"):
    st.sidebar.markdown("""
    ### How to Use This App

    **Single Review Analysis:**
    - Enter your review in the text area
    - Click 'Predict Sentiment'

    **Bulk Analysis:**
    - Upload CSV with 'Review' column
    - See results and download CSV

    **Note:**
    - Only English reviews are supported

    """)

